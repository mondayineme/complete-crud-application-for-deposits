<!DOCTYPE html>
<?php include 'db.php'; 

$page = (isset($_GET['page']) ? $_GET['page'] : 1);
$perPage = (isset($_GET['per-page']) && ($_GET['per-page']) <= 50 ? $_GET['per-page'] : 5);
$start = ($page > 1) ? ($page * $perPage) - $perPage : 0;


$sql = "select * from tasks limit ".$start." , ".$perPage." ";
$total = $db->query("select * from tasks")->num_rows;
$pages = ceil($total / $perPage);

$rows = $db->query($sql);

 

?>


<?php



$res = mysqli_query($db,'SELECT sum(amount) FROM tasks');
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$sum = $row[0];


$res = mysqli_query($db,'SELECT sum(profit) FROM tasks');
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$sump = $row[0];

?>

<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<title>Cash Deposits</title>
</head>
<body>

<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">GODGIFT-CONNECT</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>


<div class="container">


<div class="row" style="margin-top: 70px;">
<center style="margin-buttom: 70px;"><h1>Cash Deposits</h1></center>
	<div class="col-md-10 col-md-offset-1" >
		<table class="table">
			<button type="button" data-target="#myModal" data-toggle="modal" class="btn btn-success " style="margin-top: 40px;">Add Transaction</button>
			<button type="button" class="btn btn-default pull-right" style="margin-top: 40px;" onclick="print()">Print</button>
			<hr><br>
			<!-- Modal -->
			<div id="myModal" class="modal fade" role="dialog">
				<div class="modal-dialog">
					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Add Transaction</h4>
						</div>
						<div class="modal-body">
							<form method="post" action="add.php">
								<div class="form-group">
									<label>Amount</label>
									<input type="text" required name="amount" class="form-control">
								</div>
								<div class="form-group">
									<label>Profit</label>
									<input type="text" required name="profit" class="form-control">
								</div>
								<input type="submit" name="send" value="Add Task" class="btn btn-success">
							</form>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						</div>
					</div>
				</div>
			</div>
			<table class="table table-hover">
				<thead>
					<tr>
						<th>ID.</th>
						<th>Amount</th>
						<th>Profit</th>
						<th>Time</th>
						<th>Adminitration</th>
						
					</tr>
				</thead>
				<tbody>
					<tr>
					<?php while($row = $rows->fetch_assoc()): ?>
                       


				
						<th><?php echo $row['id'] ?></th>
						<td class="col-md-10"><?php echo $row['amount'] ?> </td>
						<td class="col-md-10"><?php echo $row['profit'] ?> </td>
						<td class="col-md-10"><?php echo $row['created_date'] ?> </td>
						<td><a href="update.php?id=<?php echo $row['id'];?>" class="btn btn-success">Edit</a> </td>
		<td><a href="delete_msg.php?id=<?php echo $row['id'];?>" class="btn btn-danger">Delete</a> </td>
					</tr>
						<?php endwhile; ?>
					
				</tbody>
			</table>

			<?php

            echo "<hr>";

                             echo "<th>Total Amount: </th>";
                            echo "<tr>";
                            echo "<td>" . $sum . "</td>";
                              echo "</tr>"; 
                              echo "<hr>";

                            echo "<th>Total Profit: </th>";
                            echo "<tr>";
                            echo "<td> &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;" .$sump . "</td>";
							  echo "</tr>"; 
							  
							
                            echo "<hr>";

            ?>
			
			<div>
			<a href="delete_all.php"><button type="button" class="btn btn-danger">Delete All</button></a>
			</div>
			
			<center>
				<ul class="pagination">
				
				<?php for($i = 1 ; $i <= $pages; $i++): ?>
				<li><a href="?page=<?php echo $i;?>&per-page=<?php echo $perPage;?>"><?php echo $i; ?></a></li>

			<?php endfor; ?>
				</ul>
			</center>
		
		<center>
		
		</div>
	</div>
</div>



</body>
</html>